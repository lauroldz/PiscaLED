#ifndef PiscaLED_h
#define PiscaLED_h

#include "Arduino.h"

class PiscaLed {                                          
  public:
    PiscaLed(byte pinLed, int tempoPisca = 1000);         
    void startPisca();                                    
    void stopPisca();                                     
    void loop();                                          
  private:    
    byte pino;                                            
    int tempo;                                            
    bool estadoPisca;                                     
    unsigned long delayPisca;                             
};

#endif